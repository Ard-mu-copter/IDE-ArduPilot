
#include "PrivateMember.h"

using namespace Empty;

EmptyPrivateMember::EmptyPrivateMember(uint16_t foo) :
    _foo(foo)
{}

void EmptyPrivateMember::init() {}

