
#ifndef __AP_HAL_AVR_SITL_H__
#define __AP_HAL_AVR_SITL_H__

#include <AP_HAL.h>

#include "HAL_AVR_SITL_Class.h"
#include "AP_HAL_AVR_SITL_Main.h"

#endif // __AP_HAL_AVR_SITL_H__

