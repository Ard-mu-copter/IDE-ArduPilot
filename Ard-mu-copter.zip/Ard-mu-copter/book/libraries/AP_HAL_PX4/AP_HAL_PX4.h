
#ifndef __AP_HAL_PX4_H__
#define __AP_HAL_PX4_H__

#include <AP_HAL.h>
#include "HAL_PX4_Class.h"
#include "AP_HAL_PX4_Main.h"

#endif // __AP_HAL_PX4_H__

